import React from "react";

const Asterik = () => {
  return <span className="text-danger">*</span>;
};

export default Asterik;
