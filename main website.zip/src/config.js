// export const REACT_APP_API_BASE_URL = "https://autotitanic.onrender.com";
export const REACT_APP_API_BASE_URL = "http://localhost:4000";
export const REACT_APP_API_VERSION = "/api/v1/";
