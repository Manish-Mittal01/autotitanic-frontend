export function logData(text, data) {
  console.log(text, data);
}

export function logError(text, data) {
  console.error(text, data);
}
