export const isArray = (data) => {
  return Array.isArray(data) ? data : [];
};
